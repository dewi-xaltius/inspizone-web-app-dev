// console.log("Hello, World!!");
// //a=10;
// //console.log(a);
// var x=12;
// {
//     a=23;
//     console.log(a);
//     let z=34;
//     let y=x+z;
//     console.log(y);
// }
// console.log(a)
// const num=10;
// const num2=34;
// console.log(num);
// console.log(x);
//Javascript Datatypes
let fname="Archana"; //string
let age=40; //integer
let weight=45.7; //float
let NRIC=41564516351263n;//bigint
let iseligible=true;
let somevalue;
console.log(somevalue);
let address=null
console.log(address)
console.log("My name is",fname,"And my age is",age,".")
console.log("NRIC",NRIC,"And i am eligible for voting",iseligible)



