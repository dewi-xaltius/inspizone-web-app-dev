import React from 'react'

function greet() {
  return (
    <div><h1> Welcome Archana, you have 10 unread messages</h1></div>
  )
}

export default greet