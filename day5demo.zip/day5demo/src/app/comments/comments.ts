export const comments=[
    {id:1,text:"This is my first comment"},
    {id:2,text:"This is my second comment"},
    {id:3,text:"This is my third comment"},
    {id:4,text:"This is my fourth comment"},
]