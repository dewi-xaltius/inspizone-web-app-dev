import { ContactContainer,ContactTitle,ContactText } from "./Contact.style"
export default function Contact()
{
    return(
        <ContactContainer>
            <ContactTitle>Contact Us</ContactTitle>
            <ContactText> Fell free to contact us on contact@myblog.com </ContactText>
        </ContactContainer>
    )
}