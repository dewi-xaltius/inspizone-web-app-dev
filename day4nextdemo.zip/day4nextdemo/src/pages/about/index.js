//import Layout from '@/components/Layout'
import { AboutContainer,AboutTitle,AboutText } from './About.style'
export default function About() {
  return (

        <AboutContainer>
            <AboutTitle>About this Blog</AboutTitle>
        <AboutText>
            This blog is about sharing knowledge on web development and related topics.
            This blog is about sharing knowledge on web development and related topics.
            This blog is about sharing knowledge on web development and related topics.
        </AboutText>
        </AboutContainer>
    
  )
}
